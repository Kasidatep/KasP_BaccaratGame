package componance.ingame;

public enum slut {
    spade, heart, diamond, club;
}
